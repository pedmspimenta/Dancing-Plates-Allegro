#include <stdio.h>
#include <allegro5/allegro.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_primitives.h>
#include <stdlib.h>
#include <allegro5/allegro_audio.h>
#include <allegro5/allegro_acodec.h>

const int NUM_PRATOS = 8;
const float FPS = 100;

const int SCREEN_W = 1010;
const int SCREEN_H = 540;

// largura do jogador
const float JOGADOR_W = 50;
const float JOGADOR_H = 100;

const float MudancaMaxima = 0.001;
const float MudancaMaximaRegen = 0.03;
int UltimaAtt = 0;
int UltimaAttRegen = 0;
int ContaTempo = 100;

typedef struct Jogador
{ // JOGADOR STRUCT

	float x;
	int mov_esq, mov_dir;
	ALLEGRO_COLOR cor;
	float vel;

} Jogador;

typedef struct Pratos
{ // PRATOS STRUCT
	float x1, x2, y1, y2;
	ALLEGRO_COLOR cor;
	bool inicializaprato;
	float equilibrio;
	bool regeneracao;
} Pratos;

typedef struct Postes
{
	int x1, x2, y1, y2;
	ALLEGRO_COLOR cor_poste;
	bool inicializaposte;
	bool muda_cor;
} Postes;

void InicializaJogador(Jogador *j)
{
	j->x = SCREEN_W / 2;
	j->cor = al_map_rgb(0, 0, 255);
	j->mov_esq = 0;
	j->mov_dir = 0;
	j->vel = 2.5;
}

void InicializaPrato(Pratos pratos[])
{
	int j = 0;
	pratos[0].x1 = 100;
	pratos[0].y1 = 100;
	pratos[0].x2 = 180;
	pratos[0].y2 = 70;
	pratos[0].cor = al_map_rgb(255, 255, 255);
	pratos[0].inicializaprato = 0;
	pratos[0].equilibrio = 1;
	pratos[0].regeneracao = 0;

	for (j = 1; j < NUM_PRATOS; j++)
	{
		pratos[j].x1 = pratos[j - 1].x1 + 100;
		pratos[j].y1 = 100;
		pratos[j].x2 = pratos[j - 1].x2 + 100;
		pratos[j].y2 = 70;
		pratos[j].cor = al_map_rgb(255, 255, 255);
		pratos[j].equilibrio = 1;
		pratos[j].regeneracao = 0;
		if (j == 3 || j == 4)
		{
			pratos[j].inicializaprato = 1;
		}
		else
		{
			pratos[j].inicializaprato = 0;
		}
	}
}

void InicializaPoste(Postes poste[])
{
	int j;
	poste[0].x1 = 130;
	poste[0].x2 = 150;
	poste[0].y1 = 70;
	poste[0].y2 = 450;
	poste[0].cor_poste = al_map_rgb(255, 255, 255);
	poste[0].inicializaposte = 0;
	poste[0].muda_cor = 0;

	for (j = 1; j < NUM_PRATOS; j++)
	{
		poste[j].x1 = poste[j - 1].x1 + 100;
		poste[j].y1 = 70;
		poste[j].y2 = 450;
		poste[j].x2 = poste[j - 1].x2 + 100;
		poste[j].cor_poste = al_map_rgb(255, 255, 255);
		poste[j].muda_cor = 0;
		if (j == 3 || j == 4)
		{
			poste[j].inicializaposte = 1;
		}
		else
		{
			poste[j].inicializaposte = 0;
		}
	}
}

void desenha_cenario()
{
	ALLEGRO_COLOR BKG_COLOR = al_map_rgb(0, 0, 0);
	// colore a tela de preto (rgb(0,0,0))
	al_clear_to_color(BKG_COLOR);
}

void desenha_jogador(Jogador j)
{
	al_draw_filled_triangle(j.x, SCREEN_H - JOGADOR_H,
							j.x - JOGADOR_W / 2, SCREEN_H,
							j.x + JOGADOR_W / 2, SCREEN_H,
							j.cor);
}

void desenha_prato(Pratos pratos[], int timer)
{
	int i = 0;

	if (timer == 3)
	{
		pratos[2].inicializaprato = 1;
		pratos[5].inicializaprato = 1;
	}
	else if (timer == 6)
	{
		pratos[1].inicializaprato = 1;
		pratos[6].inicializaprato = 1;
	}
	else if (timer == 9)
	{
		pratos[0].inicializaprato = 1;
		pratos[7].inicializaprato = 1;
	}

	for (i = 0; i < NUM_PRATOS; i++)
	{
		if (pratos[i].inicializaprato)
		{
			al_draw_filled_rectangle(pratos[i].x1, pratos[i].y1, pratos[i].x2, pratos[i].y2, pratos[i].cor);
		}
	}
}

void desenha_poste(Postes poste[], int timer)
{

	int j;
	if (timer == 3)
	{
		poste[2].inicializaposte = 1;
		poste[5].inicializaposte = 1;
	}
	else if (timer == 6)
	{
		poste[1].inicializaposte = 1;
		poste[6].inicializaposte = 1;
	}
	else if (timer == 9)
	{
		poste[0].inicializaposte = 1;
		poste[7].inicializaposte = 1;
	}

	for (j = 0; j < NUM_PRATOS; j++)
	{
		if (poste[j].inicializaposte)
		{
			al_draw_filled_rectangle(poste[j].x1, poste[j].y1, poste[j].x2, poste[j].y2, poste[j].cor_poste);
		}
	}
}

void nao_desenha_poste(Postes poste[], int timer)
{
	int max = 7;
	int min = 0;

	if (timer - UltimaAtt == 1)
	{
		UltimaAtt = timer;
		if (timer % 15 == 0)
		{
			int postedesativado = rand() % (max + 1 - min) + min;
			poste[postedesativado].inicializaposte = 0;
			ContaTempo = timer;
		}
		else if (timer - ContaTempo == 5)
		{
			int i;
			for (i = 0; i < NUM_PRATOS; i++)
			{
				poste[i].inicializaposte = 1;
			}
		}
	}
}

void atualizaJogador(Jogador *j)
{
	if (j->mov_esq)
	{
		if (j->x - j->vel > 0)
			j->x -= j->vel;
	}
	if (j->mov_dir)
	{
		if (j->x + j->vel < SCREEN_W)
			j->x += j->vel;
	}
}

int equilibrioPrato(Pratos pratos[], Jogador jogador)
{
	int i;
	for (i = 0; i < NUM_PRATOS; i++)
	{
		if (pratos[i].inicializaprato)
		{
			if (pratos[i].regeneracao == 0)
			{
				pratos[i].equilibrio -= ((float)rand() / (float)(RAND_MAX)) * MudancaMaxima;
				if (pratos[i].equilibrio <= 0)
				{
					pratos[i].equilibrio = 0;
				}
				pratos[i].cor = al_map_rgb(255, 255 * pratos[i].equilibrio, 255 * pratos[i].equilibrio);
				if (!pratos[i].equilibrio)
				{
					return 0;
				}
			}
			else if (pratos[i].regeneracao == 1 && jogador.mov_dir == 0 && jogador.mov_esq == 0)
			{
				pratos[i].equilibrio += ((float)rand() / (float)(RAND_MAX)) * MudancaMaximaRegen;
				if (pratos[i].equilibrio >= 1)
				{
					pratos[i].equilibrio = 1;
				}
				pratos[i].cor = al_map_rgb(255, 255 * pratos[i].equilibrio, 255 * pratos[i].equilibrio);
			}
		}
	}
	return 1;
}

int verifica_recorde(int pontuacao)
{
	FILE *arq;
	int recorde;
	arq = fopen("recorde.txt", "r");
	fscanf(arq, "%d", &recorde);
	fclose(arq);
	if (pontuacao > recorde)
	{
		arq = fopen("recorde.txt", "w");
		fprintf(arq, "%d", pontuacao);
		fclose(arq);
		return pontuacao;
	}
	else
	{
		return recorde;
	}
}

void fim_de_jogo(Pratos pratos[], int timer, Jogador jogador, int caiu, ALLEGRO_FONT *fonte)
{

	int altura = pratos[caiu].y1;
	int pontuacao = timer / 2;
	int possivelrecorde;
	while (altura <= SCREEN_H)
	{
		altura = pratos[caiu].y2;
		desenha_cenario();
		pratos[caiu].y1 += 0.5;
		pratos[caiu].y2 += 0.5;
		al_draw_filled_rectangle(pratos[caiu].x1, pratos[caiu].y1, pratos[caiu].x2, pratos[caiu].y2, pratos[caiu].cor);
		al_flip_display();
	}

	possivelrecorde = verifica_recorde(pontuacao);
	if (possivelrecorde == pontuacao)
	{
		al_draw_textf(fonte, al_map_rgb(255, 255, 255), 505, 230, 1, "Parabens!\nNovo recorde:%d", pontuacao);
	}
	else
	{
		al_draw_textf(fonte, al_map_rgb(255, 255, 255), 505, 230, 1, "Sua pontuacao: %d", pontuacao);
		al_draw_textf(fonte, al_map_rgb(255, 255, 255), 505, 270, 1, "Recorde: %d", possivelrecorde);
	}
	al_flip_display();
	al_rest(5.0);
}

int main(int argc, char **argv)
{
	ALLEGRO_TIMER *timer = NULL;
	ALLEGRO_DISPLAY *display = NULL;
	ALLEGRO_SAMPLE *music = NULL;
	ALLEGRO_FONT *font = NULL;

	if (!al_init())
	{
		fprintf(stderr, "failed to initialize allegro!\n");
		return -1;
	}

	display = al_create_display(SCREEN_W, SCREEN_H);
	if (!display)
	{
		fprintf(stderr, "failed to create display!\n");
		al_destroy_timer(timer);
		return -1;
	}

	if (!al_init_primitives_addon())
	{
		fprintf(stderr, "failed to initialize primitives!\n");
		return -1;
	}

	// inicializa o modulo que permite carregar imagens no jogo
	if (!al_init_image_addon())
	{
		fprintf(stderr, "failed to initialize image module!\n");
		return -1;
	}

	if (!al_install_keyboard())
	{
		fprintf(stderr, "failed to install keyboard!\n");
		return -1;
	}

	if (!al_install_audio())
	{
		fprintf(stderr, "failed to install music!\n");
		return -1;
	}

	if (!al_init_acodec_addon())
	{
		fprintf(stderr, "failed to music module!\n");
		return -1;
	}

	al_init_font_addon();

	if (!al_init_ttf_addon())
	{
		fprintf(stderr, "failed to load tff font module!\n");
		return -1;
	}

	timer = al_create_timer(1.0 / FPS);
	if (!timer)
	{
		fprintf(stderr, "failed to create timer!\n");
		return -1;
	}

	font = al_load_font("pzim3x5.ttf", 50, 1);
	if (font == NULL)
	{
		fprintf(stderr, "font file does not exist or cannot be accessed!\n");
	}

	ALLEGRO_EVENT_QUEUE *event_queue = NULL;
	event_queue = al_create_event_queue();
	if (!event_queue)
	{
		fprintf(stderr, "failed to create event_queue!\n");
		al_destroy_display(display);
		al_destroy_timer(timer);
		return -1;
	}

	al_register_event_source(event_queue, al_get_display_event_source(display));

	al_register_event_source(event_queue, al_get_timer_event_source(timer));

	al_register_event_source(event_queue, al_get_keyboard_event_source());

	Jogador jogador;
	InicializaJogador(&jogador);
	Pratos pratos[NUM_PRATOS];
	InicializaPrato(pratos);
	Postes postes[NUM_PRATOS];
	InicializaPoste(postes);

	music = al_load_sample("music.ogg");

	if (!music)
	{
		printf("Erro ao carregar a música!\n");
		return -1;
	}

	al_reserve_samples(1);

	al_play_sample(music, 1.0, 0.0, 1.0, ALLEGRO_PLAYMODE_LOOP, NULL);

	al_start_timer(timer);

	int playing = 1;
	int rodando = 1;

	while (playing == 1 && rodando == 1)
	{
		ALLEGRO_EVENT ev;
		al_wait_for_event(event_queue, &ev);

		if (ev.type == ALLEGRO_EVENT_TIMER)
		{

			desenha_cenario();

			atualizaJogador(&jogador);

			desenha_jogador(jogador);

			desenha_poste(postes, (int)(al_get_timer_count(timer) / FPS));

			nao_desenha_poste(postes, (int)(al_get_timer_count(timer) / FPS));

			playing = equilibrioPrato(pratos, jogador);

			desenha_prato(pratos, (int)(al_get_timer_count(timer) / FPS));

			// atualiza a tela (quando houver algo para mostrar)
			al_flip_display();

			if (al_get_timer_count(timer) % (int)FPS == 0)
				printf("\n%d segundos se passaram...", (int)(al_get_timer_count(timer) / FPS));
		}
		else if (ev.type == ALLEGRO_EVENT_DISPLAY_CLOSE)
		{
			rodando = 0;
		}
		else if (ev.type == ALLEGRO_EVENT_KEY_DOWN)
		{
			if (ev.keyboard.keycode == ALLEGRO_KEY_A)
			{
				int i;
				jogador.mov_esq = 1;
				for (i = 0; i < NUM_PRATOS; i++)
				{
					pratos[i].regeneracao = 0;
				}
			}
			else if (ev.keyboard.keycode == ALLEGRO_KEY_D)
			{
				int i;
				jogador.mov_dir = 1;
				for (i = 0; i < NUM_PRATOS; i++)
				{
					pratos[i].regeneracao = 0;
				}
			}
			else if (ev.keyboard.keycode == ALLEGRO_KEY_SPACE)
			{
				int i;
				for (i = 0; i < NUM_PRATOS; i++)
				{
					if (jogador.x <= postes[i].x2 && jogador.x >= postes[i].x1)
					{
						pratos[i].regeneracao = 1;
						if (jogador.mov_esq == 0 && jogador.mov_dir == 0)
						{
							postes[i].cor_poste = al_map_rgb(127, 255, 212);
						}
					}
				}
			}
		}

		else if (ev.type == ALLEGRO_EVENT_KEY_UP)
		{

			if (ev.keyboard.keycode == ALLEGRO_KEY_A)
			{
				jogador.mov_esq = 0;
			}
			else if (ev.keyboard.keycode == ALLEGRO_KEY_D)
			{
				jogador.mov_dir = 0;
			}
			else if (ev.keyboard.keycode == ALLEGRO_KEY_SPACE)
			{
				int i;
				for (i = 0; i < NUM_PRATOS; i++)
				{
					pratos[i].regeneracao = 0;
					postes[i].cor_poste = al_map_rgb(255, 255, 255);
				}
			}
		}
	}

	int i;
	int prato_caiu;
	for (i = 0; i < NUM_PRATOS; i++)
	{
		if (pratos[i].equilibrio == 0)
		{
			prato_caiu = i;
		}
	}

	if (rodando)
	{
		fim_de_jogo(pratos, (int)(al_get_timer_count(timer) / FPS), jogador, prato_caiu, font);
		al_flip_display();
	}

	al_destroy_font(font);
	al_destroy_timer(timer);
	al_destroy_sample(music);
	al_destroy_display(display);
	al_destroy_event_queue(event_queue);

	return 0;
}
